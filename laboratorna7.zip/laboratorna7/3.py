import matplotlib.pyplot as plt
import pandas as pd

aim = str()
text =  open('Наполеон Хилл - Думай и Богатей.txt', 'r', encoding= "utf-8").read().lower()
for i in text:
    if '?' in i:
        aim = aim + ("?")
    elif '!' in i:
        aim = aim + ("!")
    elif '.' in i:
        aim = aim + (".")
    elif ":" in i:
        aim = aim + (":")

char = list(aim)

f = pd.DataFrame({'chars': char})
f = f[f.chars != ' ']
f['num'] = 10
f = f.groupby('chars').sum().sort_values('num', ascending=False) / len(f)

plt.bar(f.index, f.num, width=0.5, color='g')
plt.show()
plt.savefig(input('Vveditʹ nazvu histohramy: \n'))
print("Histohrama zberezhena bilya fayla: .py")