import math
x = int (input ("Vvedit chislo x: "))
if x > 45.00:
    z = -(math.sqrt (x))
elif x <= 45.00:
    z = math.sin (2*x)
print(z)