import math
p = int( input ("Vvedit chislo p: "))
f1 = 0
f2 = 1
fn = 1
while p > fn :
    fn = f1 + f2
    f1 = f2
    f2 = fn
print (fn)