import math

m = [int(i) for i in input("Vvedit elementy masiva: ").split()]
a = m
#максимальний елемент списку
b= max (a)
print (b)

#середнє арифметичне від`ємних значень 
m = [i for i in a if i<0]
s = (sum (m))/(len (m)) 
print (s)

#вивести масив в зворотньому порядку
r = a
list.reverse (a)
print (r)