import collections

class Str():

    def repeat(self, str_value):
        dictionary ={}
        splitt = collections.Counter(str_value)
        for key, str in splitt.items():
            dictionary[key] = str
            if str >=3: 
                print("False")
                return False
            else:
                print("True")
                return True

    def pal(self, str_value):
        reverse_str = str_value[::-1]
        if str_value == reverse_str:
            print("True")
            return True
        else:
            print("False")
            return False

print("Vveditʹ slova na analiz: ")

s=Str()
s.repeat(input("Chy mistytʹ ryadok povtory poslidovnosti vid 3 symvoliv? .\n"))
s.pal(input("Chy ye ryadok palindrom? .\n"))