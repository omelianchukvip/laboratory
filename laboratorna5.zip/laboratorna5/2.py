class Student(object):

    grade={
        'examen_max':100,
        'lab_max':10,
        'lab':5,
         'k':0.6,
    }

    def __init__(self,name: str,grade: float ):
        self.name=name
        self.grade=grade

    def time_exam(self, tim: int, lev:float):
        print(f'times:{tim}\n level:{lev}')

    def times_lab(self, time=int, lab=float):
        print(f'Time:{time}\n Lab:{lab}')

student=Student("Roman", 5)
student.time_exam(5,4)
student.times_lab(5,4)