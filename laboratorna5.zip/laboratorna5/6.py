class Venicle():

    def method(self, x,y,c):
        self.x=x
        self.y=y
        self.c=c
        print(self.x, self.y, self.c)


class AirFly(Venicle):

    def method1(self,x,y):
        self.x=x
        self.y=y
        print(self.x, self.y)


class Ship(Venicle):

    def method2(self,y,c):
        self.y=y
        self.c=c
        print(self.y, self.c)


class Car(Venicle):

    def method3(self, x,y,c):
        self.x=x
        self.y=y
        self.c=c
        print(self.x, self.y, self.c)

a=AirFly()
a.method1("1300 metriv", "152 pasazhyrа")

b=Ship()
b.method2("Kyiv", "76 pasazhyriv")

d = Car()
d.method3("50 km/chas", "2006 rik vypusku", "2000$")