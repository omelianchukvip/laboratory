import pandas as pd

class Library:
    data=pd.DataFrame()

    def add_book(self, name:str, author: str, year: int, genre: str):
        data_book={"Nazva":name, "Avtor": author, "Rik": year, "Zhanr": genre}
        self.data=self.data.append(data_book, ignore_index=True)
        print(self.data)

    def delete_book(self, book_id: int):
        if len(self.data) == 0:
            print("U bibliotetsi nemaye knyh")
        else:
            self.data = self.data.drop(book_id)
            print(self.data)

    def where_book(self, book_id: int):
        all_indexes = self.data.head()
        for i in all_indexes.index:
            if all_indexes.index[i] == book_id:
                print(pd.DataFrame(self.data.iloc[book_id]))

l=Library()
l.add_book("Думай и богатей","	Наполеон Хилл", 1937,"Психология")
l.add_book("Самый богатый человек в Вавилоне","Джордж С. Клейсон",1926 ,"Бизнес книги")

or1 = int(input('dodaty knyhu biblioteku?   P.S. 1 - Tak, 2 - Ni\n '))
if or1 == 1:
    rang1 = int(input('Vveditʹ kilʹkistʹ knyh, yaki potribno dodaty:\n '))
    for i in range(rang1):
        name = input("Nazva:")
        author = input("Avtor:")
        year = input("Rik:")
        genre = input("Zhanr:")
        l.add_book(name, author, year, genre)
else:
    exit

delete = int(input("Vydalyty knyhu z biblioteky? P.S. 1 - Так, 2 - Ні\n"))
if delete == 1:
    c1 = int(input("Yakyy nomer knyhy vydalyty? \n"))
    l.delete_book(c1)
else:
    exit

f = int(input("znayty knyhu za nomerom?   P.S.  1 - Tak, 2 - Ni\n"))
if f == 1:
    c2 = int(input("Vveditʹ nomer knyhy: \n"))
    l.where_book(c2)
else:
    exit