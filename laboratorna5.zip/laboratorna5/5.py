import collections
import pandas as pd

class Translator():

    def func(self, x:str ,y:float,c:float):
        self.x=x
        self.y=y
        self.c=c
        print(self.x, self.y, self.c)

    def func2(self, x:str ,y:float,c:float):
        self.x=x
        self.y=y
        self.c=c
        print(self.x, self.y)

f=Translator()
print("Alʹternatyvnyy pereklad: ")
f.func("pattern", "шаблон", "візерунок")
print("Pereklad")
f.func2("trigger", "тригер","курок")