import csv
import random

s = ["Рома ", "Кіт ", "Пес "]
e = ["виграв ", "з'їв ", "поцупив "]
x = ["10 гривень","пельмень","джекпот"]

i = 1
while i == 1:
    print (random.choice(s)+random.choice(e)+random.choice(x))
    i = float(input("Го ще?  P.S. 1 - Tak, 2 - Ni  " ))