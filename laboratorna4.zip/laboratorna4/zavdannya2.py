import re
import os

a = 0
dictionary = {}
file = open('Наполеон Хилл - Думай и Богатей.txt', 'r', encoding= "utf-8").read().lower()
match_style = re.findall(r'\b[а-я]{1,30}\b', file)

for words in match_style:
    q = int(f' {match_style.count(words)}')
    r = ( f'{words}')
    if q < 2:
        a = a + 1

def counter(fname):
    num_word = 0
    num_char = 0
    num_space = 0
    contrast = set()

    with open("Наполеон Хилл - Думай и Богатей.txt", 'r', encoding="utf-8") as f:

        for line in f:
            line = line.strip(os.linesep)
            words_list = line.split()
            num_word = num_word + len(words_list)
            num_char = num_char + sum(1 for c in line

                if c not in (os.linesep, ' '))
                    
            num_space = num_space + num_char + sum(1 for s in line

                if s in (os.linesep, ' '))

            contrast |= set(line.split())

    print("Kilʹkistʹ symvoliv bez probiliv u tekstovomu fayli: ", num_char)
    print("Kilʹkistʹ symvoliv z probilamy v tekstovomu fayli: ", num_space)
    print("Kilʹkistʹ sliv u tekstovomu fayli: ", num_word)
    print(f"zahalʹna kilʹkistʹ riznykh sliv (bez povtoriv): {len(contrast)}")
    print("Unikalʹni slova: ",a)

if __name__ == '__main__':
    fyle_name = 'File1.txt'
    try:
        counter(fyle_name)
    except:
        print('fayl ne znaydeno')