import re

a = 0
file = open('Наполеон Хилл - Думай и Богатей.txt', 'r', encoding= "utf-8").read().lower()
match_style = re.findall(r'\b[а-я]{3,30}\b', file)
for words in match_style:
    b = int(f' {match_style.count(words)}')
    k = ( f'{words}')
    if b > a:
        a = b
        d = k
print("Naydovsha poslidovnistʹ sliv: ",a)
print("Iz slova: ", [d])