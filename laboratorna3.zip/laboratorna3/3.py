import os
import io
import csv

#zapys danykh u 1 fayl
print("First_file.txt")
f1 = "First_file.txt"
fd = open(f1, "w")
fd.close()

#redahuvannya 1 faylu
fd = open(f1, "a")
or12 = int(input('dodaty studenta v 1 fayl?  P.S. 1 - Tak, 2 - Ni \n '))
if or12 == 1:
    a = input("Vveditʹ prizvyshche:")
    b = input("Vveditʹ seredniy bal:")
    fd.write(a+" = "+b)
else:
    fd.close()

#chytannya z 1 faylu
fd = open(f1, "r")
reader = csv.reader(fd, delimiter = "\t")
for str in reader:
    print(str)
fd.close()

#zapys danykh u 2 fayl
print("Second_file.txt")
f2 = "Second_file.txt"
fd = open(f2, "w")
fd.close()

#redahuvannya 2 faylu
fd = open(f2, "a")
or1 = int(input('dodaty studenta v 2 fayl?  P.S. 1 - Так, 2 - Ні \n '))
if or1 == 1:
    a = input("Vveditʹ prizvyshche:")
    b = input("Vveditʹ seredniy bal:")
    fd.write(a+" = "+b)
else:
    fd.close()

#chytannya z 2 faylu
fd = open(f2, "r")
reader = csv.reader(fd, delimiter="\t")
for str in reader:
 print(str)
fd.close()

#poshuk studenta v fayli
a = int(input("Oberitʹ fayl ('First_file.txt' - 1, 'Second_file.txt' - 2)\n"))
trigger = True
while trigger:
    if a == 1:
        fs = open(f1).read()
        f = open(f1)
    if a == 2:
        fs = open(f2).read()
        f = open(f2)
    if a!=1 and a!=2:
        print("fayl ne znaydeno")
        break
    w = input("Vveditʹ prizvyshche studenta, shchob perehlyanuty seredniy bal:\n")
    if w in fs:
        for i in f.readlines():
            if i.find(w) > -1:
                print(i.strip())
                trigger = False
                break
    else:
        print("Studenta ne znaydeno")