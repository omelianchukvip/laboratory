from PyQt5.QtWidgets import QApplication, QMainWindow, QGridLayout, QWidget, QTableWidget, QTableWidgetItem
from PyQt5.QtCore import QSize, Qt


# Nasliduyuchy vid QMainWindow
class MainWindow(QMainWindow):
    # Perevyznachyty konstruktor klasu
    def __init__(self):
        # Obov'yazkovo potribno vyklykaty metod superklassa
        QMainWindow.__init__(self)

        self.setMinimumSize(QSize(480, 80))  # vstanovlyuyemo rozmiry
        self.setWindowTitle("Товарооб1г_ун1вермагу")  # Vstanovlyuyemo zaholovok vikna
        central_widget = QWidget(self)  # Stvoryuyemo tsentralʹnyy vidzhet
        self.setCentralWidget(central_widget)  # Vstanovlyuyemo tsentralʹnyy vidzhet

        grid_layout = QGridLayout()  # stvoryuyemo QGridLayout
        central_widget.setLayout(grid_layout)  # Vstanovlyuyemo dane rozmishchennya v tsentralʹnyy vidzhet

        table = QTableWidget(self)  # stvoryuyemo tablytsyu
        table.setColumnCount(4)  # Vstanovlyuyemo kolonky
        table.setRowCount(15)  # Vstanovlyuyemo ryadky

        # Vstanovlyuyemo zaholovky tablytsi
        table.setHorizontalHeaderLabels(["Код товарної групи\nKODT", "Товарообіг\nПлан\nTOP", "Товарообіг\nОчікуєме виконання\nTOO", "Рік\nGOD"])

        # Vstanovlyuyemo splyvayuchi pidkazky na zaholovky
        table.horizontalHeaderItem(0).setToolTip("Column 1 ")
        table.horizontalHeaderItem(1).setToolTip("Column 2 ")
        table.horizontalHeaderItem(2).setToolTip("Column 3 ")


        # zapovnyuyemo pershyy ryadok
        table.setItem(0, 0, QTableWidgetItem("1000"))
        table.setItem(0, 1, QTableWidgetItem("4340"))
        table.setItem(0, 2, QTableWidgetItem("4420"))
        table.setItem(0, 3, QTableWidgetItem("2013"))

        table.setItem(1, 0, QTableWidgetItem("2000"))
        table.setItem(1, 1, QTableWidgetItem("6280"))
        table.setItem(1, 2, QTableWidgetItem("6720"))
        table.setItem(1, 3, QTableWidgetItem("2013"))

        table.setItem(2, 0, QTableWidgetItem("3000"))
        table.setItem(2, 1, QTableWidgetItem("5260"))
        table.setItem(2, 2, QTableWidgetItem("5854"))
        table.setItem(2, 3, QTableWidgetItem("2013"))

        table.setItem(3, 0, QTableWidgetItem("4000"))
        table.setItem(3, 1, QTableWidgetItem("3720"))
        table.setItem(3, 2, QTableWidgetItem("3682"))
        table.setItem(3, 3, QTableWidgetItem("2013"))

        table.setItem(4, 0, QTableWidgetItem("5000"))
        table.setItem(4, 1, QTableWidgetItem("2410"))
        table.setItem(4, 2, QTableWidgetItem("2694"))
        table.setItem(4, 3, QTableWidgetItem("2013"))

        table.setItem(5, 0, QTableWidgetItem("1000"))
        table.setItem(5, 1, QTableWidgetItem("4600"))
        table.setItem(5, 2, QTableWidgetItem("4640"))
        table.setItem(5, 3, QTableWidgetItem("2014"))

        table.setItem(6, 0, QTableWidgetItem("2000"))
        table.setItem(6, 1, QTableWidgetItem("6800"))
        table.setItem(6, 2, QTableWidgetItem("7400"))
        table.setItem(6, 3, QTableWidgetItem("2014"))

        table.setItem(7, 0, QTableWidgetItem("3000"))
        table.setItem(7, 1, QTableWidgetItem("6000"))
        table.setItem(7, 2, QTableWidgetItem("6250"))
        table.setItem(7, 3, QTableWidgetItem("2014"))

        table.setItem(8, 0, QTableWidgetItem("4000"))
        table.setItem(8, 1, QTableWidgetItem("3800"))
        table.setItem(8, 2, QTableWidgetItem("3850"))
        table.setItem(8, 3, QTableWidgetItem("2014"))

        table.setItem(9, 0, QTableWidgetItem("5000"))
        table.setItem(9, 1, QTableWidgetItem("2700"))
        table.setItem(9, 2, QTableWidgetItem("3000"))
        table.setItem(9, 3, QTableWidgetItem("2014"))

        table.setItem(10, 0, QTableWidgetItem("1000"))
        table.setItem(10, 1, QTableWidgetItem("4700"))
        table.setItem(10, 2, QTableWidgetItem("4625"))
        table.setItem(10, 3, QTableWidgetItem("2015"))

        table.setItem(11, 0, QTableWidgetItem("2000"))
        table.setItem(11, 1, QTableWidgetItem("6700"))
        table.setItem(11, 2, QTableWidgetItem("6630"))
        table.setItem(11, 3, QTableWidgetItem("2015"))

        table.setItem(12, 0, QTableWidgetItem("3000"))
        table.setItem(12, 1, QTableWidgetItem("6700"))
        table.setItem(12, 2, QTableWidgetItem("6500"))
        table.setItem(12, 3, QTableWidgetItem("2015"))

        table.setItem(13, 0, QTableWidgetItem("4000"))
        table.setItem(13, 1, QTableWidgetItem("4300"))
        table.setItem(13, 2, QTableWidgetItem("4500"))
        table.setItem(13, 3, QTableWidgetItem("2015"))

        table.setItem(14, 0, QTableWidgetItem("5000"))
        table.setItem(14, 1, QTableWidgetItem("3500"))
        table.setItem(14, 2, QTableWidgetItem("3590"))
        table.setItem(14, 3, QTableWidgetItem("2015"))



        # robymo resayz kolonok po vmistu
        table.resizeColumnsToContents()

        grid_layout.addWidget(table, 0, 0)  # Dodayemo tablytsyu v sitku


if __name__ == "__main__":
    import sys

    app = QApplication(sys.argv)
    mw = MainWindow()
    mw.show()
    sys.exit(app.exec())