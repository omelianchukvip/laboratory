from tkinter import *
from subprocess import call

root=Tk()
root.title("ЗАВДАННЯ № 9")
root.geometry('300x300')
frame = Frame(root)
frame.pack(pady=50,padx=10)

def Open():
    call(["python", "Дов1дник_товарних_груп.py"])

btn=Button(frame,text='Дов1дник_товарних_груп',command=Open)
btn.pack()

def Open1():
    call(["python", "Товарооб1г_ун1вермагу.py"])

btn=Button(frame,text='Товарооб1г_ун1вермагу',command=Open1)
btn.pack()

def Open2():
    call(["python", "Валовий_доходу_ун1вермагу_на_поточний_р1к.py"])

btn=Button(frame,text='Валовий_доходу_ун1вермагу_на_поточний_р1к',command=Open2)
btn.pack()

root.mainloop()
