from PyQt5.QtWidgets import QApplication, QMainWindow, QGridLayout, QWidget, QTableWidget, QTableWidgetItem
from PyQt5.QtCore import QSize, Qt


# Nasliduyuchy vid QMainWindow
class MainWindow(QMainWindow):
    # Perevyznachyty konstruktor klasu
    def __init__(self):
        # Obov'yazkovo potribno vyklykaty metod superklassa
        QMainWindow.__init__(self)

        self.setMinimumSize(QSize(480, 80))  # vstanovlyuyemo rozmiry
        self.setWindowTitle("Дов1дник_товарних_груп")  # Vstanovlyuyemo zaholovok vikna
        central_widget = QWidget(self)  # Stvoryuyemo tsentralʹnyy vidzhet
        self.setCentralWidget(central_widget)  # Vstanovlyuyemo tsentralʹnyy vidzhet

        grid_layout = QGridLayout()  # stvoryuyemo QGridLayout
        central_widget.setLayout(grid_layout)  # Vstanovlyuyemo dane rozmishchennya v tsentralʹnyy vidzhet

        table = QTableWidget(self)  # stvoryuyemo tablytsyu
        table.setColumnCount(3)  # Vstanovlyuyemo kolonky
        table.setRowCount(5)  # Vstanovlyuyemo ryadky

        # Vstanovlyuyemo zaholovky tablytsi
        table.setHorizontalHeaderLabels(["Код товарної групи\nKODT", "Найменування товарної групи\nNAMET", "Торгова скидка, %\nTSKI"])

        # Vstanovlyuyemo splyvayuchi pidkazky na zaholovky
        table.horizontalHeaderItem(0).setToolTip("Column 1 ")
        table.horizontalHeaderItem(1).setToolTip("Column 2 ")
        table.horizontalHeaderItem(2).setToolTip("Column 3 ")


        # zapovnyuyemo pershyy ryadok
        table.setItem(0, 0, QTableWidgetItem("1000"))
        table.setItem(0, 1, QTableWidgetItem("Тканини"))
        table.setItem(0, 2, QTableWidgetItem("4"))
        
        table.setItem(1, 0, QTableWidgetItem("2000"))
        table.setItem(1, 1, QTableWidgetItem("Одяг та білизна"))
        table.setItem(1, 2, QTableWidgetItem("7,5"))
        
        table.setItem(2, 0, QTableWidgetItem("3000"))
        table.setItem(2, 1, QTableWidgetItem("Взуття"))
        table.setItem(2, 2, QTableWidgetItem("7,5"))
   
        table.setItem(3, 0, QTableWidgetItem("4000"))
        table.setItem(3, 1, QTableWidgetItem("Трикотаж"))
        table.setItem(3, 2, QTableWidgetItem("7,5"))
       
        table.setItem(4, 0, QTableWidgetItem("5000"))
        table.setItem(4, 1, QTableWidgetItem("Галантерея"))
        table.setItem(4, 2, QTableWidgetItem("9,5"))
           

        # робимо ресайз колонок по вмісту
        table.resizeColumnsToContents()

        grid_layout.addWidget(table, 0, 0)  # Dodayemo tablytsyu v sitku


if __name__ == "__main__":
    import sys

    app = QApplication(sys.argv)
    mw = MainWindow()
    mw.show()
    sys.exit(app.exec())
