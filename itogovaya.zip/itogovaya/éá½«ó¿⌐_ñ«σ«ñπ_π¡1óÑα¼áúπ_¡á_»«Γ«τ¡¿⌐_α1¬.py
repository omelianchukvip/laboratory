from PyQt5.QtWidgets import QApplication, QMainWindow, QGridLayout, QWidget, QTableWidget, QTableWidgetItem
from PyQt5.QtCore import QSize, Qt


# Nasliduyuchy vid QMainWindow
class MainWindow(QMainWindow):
    # Perevyznachyty konstruktor klasu
    def __init__(self):
        # Obov'yazkovo potribno vyklykaty metod superklassa
        QMainWindow.__init__(self)

        self.setMinimumSize(QSize(480, 80))  # vstanovlyuyemo rozmiry
        self.setWindowTitle("Валовий_доходу_ун1вермагу_на_поточний_р1к")  # Vstanovlyuyemo zaholovok vikna
        central_widget = QWidget(self)  # Stvoryuyemo tsentralʹnyy vidzhet
        self.setCentralWidget(central_widget)  # Vstanovlyuyemo tsentralʹnyy vidzhet

        grid_layout = QGridLayout()  # stvoryuyemo QGridLayout
        central_widget.setLayout(grid_layout)  # Vstanovlyuyemo dane rozmishchennya v tsentralʹnyy vidzhet

        table = QTableWidget(self)  # stvoryuyemo tablytsyu
        table.setColumnCount(7)  # Vstanovlyuyemo kolonky
        table.setRowCount(7)  # Vstanovlyuyemo ryadky


        # Vstanovlyuyemo zaholovky tablytsi
        table.setHorizontalHeaderLabels(["Найменування\n товарної групи", "Рік", "Товарообіг, тис.крб.\nПлан","Товарообіг, тис.крб.\nОчікуване виконання", "Торгова скидка, %", "Валовий доход,тис.крб.\nПлан" ,"Валовий доход,тис.крб.\nОчікуване виконання"])

        # Vstanovlyuyemo splyvayuchi pidkazky na zaholovky
        table.horizontalHeaderItem(0).setToolTip("Column 1 ")
        table.horizontalHeaderItem(1).setToolTip("Column 2 ")
        table.horizontalHeaderItem(2).setToolTip("Column 3 ")


        # zapovnyuyemo pershyy ryadok
        table.setItem(0, 0, QTableWidgetItem("Взуття"))
        table.setItem(0, 1, QTableWidgetItem("2013"))
        table.setItem(0, 2, QTableWidgetItem("5260,0"))
        table.setItem(0, 3, QTableWidgetItem("5854,0"))
        table.setItem(0, 4, QTableWidgetItem("7,5"))
        table.setItem(0, 5, QTableWidgetItem("50250,0"))
        table.setItem(0, 6, QTableWidgetItem("43905,0"))

        table.setItem(1, 0, QTableWidgetItem("Взуття"))
        table.setItem(1, 1, QTableWidgetItem("2014"))
        table.setItem(1, 2, QTableWidgetItem("6000,0"))
        table.setItem(1, 3, QTableWidgetItem("6250,0"))
        table.setItem(1, 4, QTableWidgetItem("7,5"))
        table.setItem(1, 5, QTableWidgetItem("17360,0"))
        table.setItem(1, 6, QTableWidgetItem("46875,0"))
        
        table.setItem(2, 0, QTableWidgetItem("Взуття"))
        table.setItem(2, 1, QTableWidgetItem("2015"))
        table.setItem(2, 2, QTableWidgetItem("6700,0"))
        table.setItem(2, 3, QTableWidgetItem("6500,0"))
        table.setItem(2, 4, QTableWidgetItem("7,5"))
        table.setItem(2, 5, QTableWidgetItem("18800,0"))
        table.setItem(2, 6, QTableWidgetItem("48750,0"))

        table.setItem(3, 0, QTableWidgetItem("..."))
        table.setItem(3, 1, QTableWidgetItem("..."))
        table.setItem(3, 2, QTableWidgetItem("..."))
        table.setItem(3, 3, QTableWidgetItem("..."))
        table.setItem(3, 4, QTableWidgetItem("..."))
        table.setItem(3, 5, QTableWidgetItem("..."))
        table.setItem(3, 6, QTableWidgetItem("..."))

        table.setItem(4, 0, QTableWidgetItem("Трикотаж"))
        table.setItem(4, 1, QTableWidgetItem("2013"))
        table.setItem(4, 2, QTableWidgetItem("3720,0"))
        table.setItem(4, 3, QTableWidgetItem("3682,0"))
        table.setItem(4, 4, QTableWidgetItem("7,5"))
        table.setItem(4, 5, QTableWidgetItem("22895,0"))
        table.setItem(4, 6, QTableWidgetItem("27615,0"))

        table.setItem(5, 0, QTableWidgetItem("Трикотаж"))
        table.setItem(5, 1, QTableWidgetItem("2014"))
        table.setItem(5, 2, QTableWidgetItem("3800,0"))
        table.setItem(5, 3, QTableWidgetItem("3850,0"))
        table.setItem(5, 4, QTableWidgetItem("7,5"))
        table.setItem(5, 5, QTableWidgetItem("33250,0"))
        table.setItem(5, 6, QTableWidgetItem("28875,0"))

        table.setItem(6, 0, QTableWidgetItem("Трикотаж"))
        table.setItem(6, 1, QTableWidgetItem("2015"))
        table.setItem(6, 2, QTableWidgetItem("4300,0"))
        table.setItem(6, 3, QTableWidgetItem("4500,0"))
        table.setItem(6, 4, QTableWidgetItem("7,5"))
        table.setItem(6, 5, QTableWidgetItem("27900,0"))
        table.setItem(6, 6, QTableWidgetItem("33750,0"))


        # robymo resayz kolonok po vmistu
        table.resizeColumnsToContents()

        grid_layout.addWidget(table, 0, 0)  # Dodayemo tablytsyu v sitku


if __name__ == "__main__":
    import sys

    app = QApplication(sys.argv)
    mw = MainWindow()
    mw.show()
    sys.exit(app.exec())
